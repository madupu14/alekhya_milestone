package com.alekhya.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alekhya.entity.Product;
import com.alekhya.repository.ProductRepository;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public Optional<Product> getProductById(Long id) {
        return productRepository.findById(id);
    }

    public List<Product> getProductsByType(String type) {
        return productRepository.findByType(type);
    }

    public Product saveProduct(Product product) {
        return productRepository.save(product);
    }
}
