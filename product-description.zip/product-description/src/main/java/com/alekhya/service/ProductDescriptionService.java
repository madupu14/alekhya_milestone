package com.alekhya.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alekhya.entity.ProductDescription;
import com.alekhya.repository.ProductDescriptionRepository;

import java.util.Optional;

@Service
public class ProductDescriptionService {

    @Autowired
    private ProductDescriptionRepository productDescriptionRepository;

    public Optional<ProductDescription> getProductDescriptionById(Long id) {
        return productDescriptionRepository.findById(id);
    }

    public ProductDescription saveProductDescription(ProductDescription productDescription) {
        return productDescriptionRepository.save(productDescription);
    }
}

