package com.alekhya.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.alekhya.entity.ProductDescription;
import com.alekhya.service.ProductDescriptionService;

import java.util.Optional;

@RestController
@RequestMapping("/product-descriptions")
public class ProductDescriptionController {

    @Autowired
    private ProductDescriptionService productDescriptionService;

    @GetMapping("/{id}")
    public ResponseEntity<ProductDescription> getProductDescriptionById(@PathVariable Long id) {
        Optional<ProductDescription> productDescription = productDescriptionService.getProductDescriptionById(id);
        return productDescription.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<ProductDescription> createProductDescription(@RequestBody ProductDescription productDescription) {
        ProductDescription savedProductDescription = productDescriptionService.saveProductDescription(productDescription);
        return new ResponseEntity<>(savedProductDescription, HttpStatus.CREATED);
    }
}

