package com.alekhya.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.alekhya.entity.ProductDescription;

public interface ProductDescriptionRepository extends JpaRepository<ProductDescription, Long> {
    
}
